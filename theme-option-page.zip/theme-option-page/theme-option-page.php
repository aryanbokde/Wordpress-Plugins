<?php 

/**
 *	@wordpress-plugin
 * Plugin Name:       Add Theme Options page
 * Plugin URI:        https://arsenaltech.com/
*/

/*
 * If some direct access this file denied.
 */
if ( ! defined( 'ABSPATH' ) ){
    die();
}
/*
 * Uses the 'admin_menu' hook to load 'ast_update_menu'.
 */
add_action( 'admin_menu', 'ast_update_menu' );


/*
 * Creates a sub-menu under appearance.
 */
function ast_update_menu() {
    add_theme_page( 'Theme options', 'Theme options', 'manage_options', 'ast-theme-options', 'ast_theme_options' );
    //add_theme_page( 'extra', 'extra', 'manage_options', 'ast-extra', 'ast_theme_extra' );
}


/*
 * Uses the 'admin_init' hook to load 'ast_init_settings'.
 */
add_action( 'admin_init', 'ast_init_settings' );


/*
 * Callback function for add_theme_page.
 * Displays the theme options page.
 */
function ast_theme_options() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'You do not have sufficient permissions to access this page.' );
    } ?>
    <div class="wrast">
        <form action="options.php" method="post">
            <?php
                settings_fields( "ast_options" );
                do_settings_sections( "ast-theme-options" );
                submit_button();
            ?>
        </form>
    </div>
<?php }


/*
 * Registers and adds settings, sections and fields.
 */
function ast_init_settings() {
    // Register a general setting.
    // The $option_group is the same as $option_name to prevent the "Error: options page not found." problem.
    register_setting( "ast_options", "ast_options", "ast_options_validate" );

    // Add sections.
    add_settings_section( "general-section", "General settings", "general_section_callback", "ast-theme-options" );

    // Add settings fields.
add_settings_field( "ast-test-field-1", "Test field 1", "test_field_1_callback", "ast-theme-options", "general-section" );
add_settings_field( "ast-test-field-2", "Test field 2", "test_field_2_callback", "ast-theme-options", "general-section" );
add_settings_field( "ast-checkbox-3", "Checkbox", "test_field_3_callback", "ast-theme-options", "general-section" );
add_settings_field( "ast-radio-4", "Radio", "test_field_4_callback", "ast-theme-options", "general-section" );

    register_setting( "ast_options", "ast-test-field-1", "ast_options_validate");
    register_setting( "ast_options", "ast-test-field-2", "ast_options_02_validate");
    register_setting( "ast_options", "ast-checkbox-3");
    register_setting( "ast_options", "ast-radio-4");
}



/*
 * Callback function for add_settings_section.
 * Displays the section HTML.
 */
function general_section_callback($arg) {
    echo "<p>This is a section description.</p>";
    // echo "ID : " .$arg['id'];
}


/*
 * Callback function for add_settings_field.
 * Displays the HTML for the field.
 */
function test_field_1_callback() {
    $options = get_option( 'ast_options' ); ?>
    <input type='text' name='ast_options[ast-test-field-1]' value='<?php echo $options['ast-test-field-1']; ?>'>

<?php }

function test_field_2_callback() {
    $options = get_option( 'ast-test-field-2' ); ?>
    
    <select name="ast-test-field-2">
        <?php 
            for( $i = 1; $i <= 100; $i++){ ?>
                <option value="<?php echo $i; ?>" <?php if($options == $i){ echo "selected='selected'";} ?>><?php echo $i; ?></option>
            <?php }
        ?>
    </select>
    
<?php }

function test_field_3_callback() {
    $options = get_option( 'ast-checkbox-3' ); ?>
    <input type="checkbox" name="ast-checkbox-3" value="checked" <?php if($options == "checked"){echo "checked";} ?>>
    <?php echo $options; ?>
<?php }


function test_field_4_callback() {
    $options = get_option( 'ast-radio-4' ); ?>
    <input type="checkbox" name="ast-radio-4" <?php if($options == "on"){echo "checked";} ?>>
    <?php echo $options; ?>
<?php }


/*
 * Sanitizes the settings.
 */
function ast_options_validate( $input ) {
    $validated['ast-test-field-1'] = sanitize_text_field( $input['ast-test-field-1'] );    
    return $validated;
}

/*
 * Sanitizes the settings.
 */
function ast_options_02_validate( $input ) {
    $validated = intval( $input);    
    return $validated;
}