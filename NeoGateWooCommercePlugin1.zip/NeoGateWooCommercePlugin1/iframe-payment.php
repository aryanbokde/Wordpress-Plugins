<style type="text/css">
    #payframe {
        min-height: 100%;
        transition: all 0.3s ease-out 0s;
        position: fixed;
        top: 0px;
        left: 0px;
        width: 100%;
        background: rgba(0, 0, 0, 0.4);
        padding-right: 15rem;
        padding-left: 15rem;
        padding-top: 3rem;
        z-index: 9999;
    }

    #payframe-child {
        position: absolute;
        right: 0px;
        top: 0px;
        padding-right: 17rem;
        padding-left: 17rem;
        padding-top: 4.3rem;
        cursor: pointer;
        font-size: 48px;
        opacity: 1;
        width: 24px;
        text-align: center;
        line-height: 0px;
        z-index: 999999;
        height: auto;
        font-weight: 600;
        color: gray;
        display: none;
    }

    #iframe {
        opacity: 7;
        position: relative;
        background: none;
        display: block;
        border: 0 px none transparent;
        margin-left: 0%;
        padding: 0px;
        z-index: 99999;
        width: 100%;
        height: 92vh;
        margin-top: 0%;
        background-color: #fff;
    }
    .pay-close-btn{
        position: relative;
        float: right;
        background: #000;
        color: white;
        padding: 5px;
        margin-bottom: -35px;
        z-index: 999999;
        font-size: 14px;
        cursor: pointer;
    }
</style>

<script>
    
    var redirect = '<?php echo $url_to_open;  ?>';
    if (window.parent.document.getElementById("iframe") != null) {
        var division = document.createElement("div");
        division.setAttribute("id", "payframe");
        division.setAttribute("style", "min-height: 100%; position: fixed; top: 0px; left: 0px; width: 100%; height: 100%; background: rgba(0,  0, 0, 0); padding-right: 0 px; padding-left: 0 px; padding-top: 0 px;");
        division.innerHTML = '<div id="payframe-child" class="close" id="F" onclick="javascript:window.parent.document.getElementById(\'iframe\').parentNode.removeChild(window.parent.document.getElementById(\'iframe\'));window.parent.document.getElementById(\'payframe\').parentNode.removeChild(window.parent.document.getElementById(\'payframe\'));">x</div><span class="pay-close-btn" id="pay-close-btn">close</span> <iframe id = "iframe" allowtransparency="true" frameborder="0" allowpaymentrequest="true" src="<?php echo $url_to_open; ?>"></iframe>';
        document.body.appendChild(division);
        //document.body.removeChild(division);
    } else {
        var division = document.createElement("div");
        division.setAttribute("id", "payframe");
        division.setAttribute("style", "");
        division.innerHTML = '<div id="payframe-child" class="close"  id="F" onclick="javascript:window.parent.document.getElementById(\'iframe\').parentNode.removeChild(window.parent.document.getElementById(\'iframe\'));window.parent.document.getElementById(\'payframe\').parentNode.removeChild(window.parent.document.getElementById(\'payframe\'));">x</div><span class="pay-close-btn" id="pay-close-btn">close</span><iframe id="iframe" allowtransparency="true" frameborder="0" allowpaymentrequest="true" src="<?php echo $url_to_open; ?>"></iframe>';
        document.body.appendChild(division);
        //document.body.removeChild(division);
    }

    
    jQuery('#pay-close-btn').click(function(){
        var homeurl = "<?php echo home_url('/checkout'); ?>"   
        console.log(homeurl);
        document.body.remove(division);
        window.location.href = homeurl;
    });

   
 
</script>

