<?php 
	get_header();

	do_shortcode("[render-my-content]");

	get_footer();
?>