<h1>Simple Book Tool</h1>
<button id="btn-front-end-ajax">First Ajax Request</button>

