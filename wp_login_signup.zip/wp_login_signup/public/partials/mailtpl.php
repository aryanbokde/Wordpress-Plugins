<table>
	<tr>
		<td><H1>Welcome to <?php echo get_bloginfo("name"); ?></H1></td>
	</tr>
	<tr>
		<td>your email verification link is <a href="<?php echo $url; ?>">Click here to verify</a> </td>
	</tr>
</table>