jQuery(document).ready(function($) { 
    
    var ajaxurl = frontendajax.ajaxurl; 
    
    // Perform AJAX login on form submit
    $('form#login').on('submit', function(e){
        e.preventDefault();
        
        var postdata = jQuery("#login").serialize();
            postdata += "&action=ajax_request_login";

        var redirecturl = $("#redirect_to").val();

        $.post(ajaxurl, postdata, function(data){
             //var errormsg = data.message;
            $('form#login p.status').html(data.message);  
             
            if (data.status == true) {
                setTimeout(function(){
                    location = redirecturl; 
                }, 1000);                    
            }
        });

    });

    // Perform AJAX login on form submit
    $('form#ast-register').on('submit', function(e){

        e.preventDefault();        
        var postdata = jQuery("#ast-register").serialize();
            postdata += "&action=ajax_request_register";

        var redirecturl = $("#redirect_to").val();

        $.post(ajaxurl, postdata, function(data){
            $('form#ast-register p.status').html(data.message);            
            if (data.status == true) {
                setTimeout(function(){
                    location = redirecturl; 
                }, 1000);                
            }
        });

    });


});

