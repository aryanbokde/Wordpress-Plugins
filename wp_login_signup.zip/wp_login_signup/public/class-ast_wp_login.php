<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://arsenaltech.com/
 * @since      1.0.0
 *
 * @package    Wp_login_signup
 * @subpackage Wp_login_signup/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wp_login_signup
 * @subpackage Wp_login_signup/public
 * @author     Rakesh <rakesh.bokde@arsenaltech.com>
 */


class Ast_Wp_login
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Resister some shortcode function when wordpress install and activate.
	 *
	 * @since    1.0.0
	 */
	public function wp_ast_login_shortcode()
	{

		add_shortcode("ast-login", array($this, "generate_shortcode_for_ast_login"));
	}

	//Ast-Login Hmtl form 
	public function generate_shortcode_for_ast_login($attr)
	{

		ob_start();
		global $wp;
		$args = shortcode_atts(array(
			'fclass' => 'default',
			'label' => 'true',
			'inputclass' => 'input-field',
			'buttonclass' => 'submit-button',
			'redirecturl' => get_home_url(),
			'logoutredirection' => 'login'

		), $attr);


		if (!is_user_logged_in()) { ?>

			<form id="login" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post" class="<?php echo $args['fclass']; ?>">
				<p class="status" id="status"></p>
				<p>
					<?php
					if ($args['label'] == 'false') {
					} else {

						echo '<label for="username">Username</label>';
					}
					?>
					<input id="username" type="text" name="username" placeholder="username or Email" class="<?php echo $args['inputclass']; ?>">
				</p>
				<p>
					<?php
					if ($args['label'] == 'false') {
					} else {
						echo '<label for="password">Password</label>';
					}
					?>
					<input id="password" type="password" name="password" placeholder="Password">
				</p>

				<p><input id="rememberme" type="checkbox" name="rememberme" value="rememberMe" class="<?php //echo $args['inputclass']; 
																										?>"> <label for="rememberme">Remember me</label></p>
				<input type="hidden" name="redirect_to" value="<?php echo $args['redirecturl']; ?>" id="redirect_to">
				<p><input class="<?php echo $args['buttonclass'] ?>" type="submit" value="Login" name="submit"></p>
				<a class="lost" href="<?php echo wp_lostpassword_url(); ?>">Lost your password?</a>
				<?php wp_nonce_field('ajax-login-nonce', 'security'); ?>
			</form>
		<?php

		} else {  ?>
			<div class="sidebox">
				<?php global $current_user; ?>
				<h3>Welcome, <strong><?php echo $current_user->user_login; ?></strong></h3>
				<div class="usericon">
					<?php global $userdata;
					echo get_avatar($userdata->ID, 60); ?>

				</div>
				<div class="userinfo">
					<p>You’re logged in as <strong><?php echo $current_user->user_login; ?></strong></p>
					<p><?php $logouturl = $args['logoutredirection']; ?>
						<a href="<?php echo wp_logout_url($logouturl); ?>">Log out</a> |
						<?php if (current_user_can('manage_options')) {
							echo '<a href="' . admin_url() . '">' . __('Admin') . '</a>';
						} else {
							echo '<a href="' . admin_url() . 'profile.php">' . __('Profile') . '</a>';
						} ?>

					</p>
				</div>
				<?php

				?>
			</div>
<?php }

		$html_form = ob_get_clean();
		return $html_form;
	}

	public function handle_public_ajax_request_login()
	{


		global $user_ID;
		global $wpdb;

		$username = $wpdb->escape($_POST['username']);
		$password = $wpdb->escape($_POST['password']);

		$info = array();
		$info['user_login'] = $_POST['username'];
		$info['user_password'] = $_POST['password'];
		$info['remember'] = $_POST['rememberme'];



		if ($info['remember'] == "rememberMe") {
			$info['remember'] = true;
		} else {
			$info['remember'] = false;
		}

		$user = get_user_by('login', $info['user_login']);
		if (!$user) {
			$user = get_user_by('email', $info['user_login']);
		}
		$userStatus = get_user_meta($user->ID, 'is_activated', true);


		// Check CSRF token	    
		if (!check_ajax_referer('ajax-login-nonce', 'security', false)) {
			echo wp_send_json(array('status' => false, 'message' => '<div class="alert alert-danger">Session token has expired, please reload the page and try again.</div>'));
		} elseif (empty($username) || empty($password)) {
			echo wp_send_json(array('status' => false, 'message' => '<div class="alert alert-danger">Wrong username or password.</div>'));
		} else { // Now we can insert this account
			$user = wp_signon($info, $info['remember']);
			if (is_wp_error($user)) {
				echo wp_send_json(array('status' => false, 'message' => '<div class="alert alert-danger">' . $user->get_error_message() . '</div>'));
			} else {

				wp_set_auth_cookie($user->ID, false);
				wp_set_current_user($user->ID, $user->user_login);
				do_action('wp_login', $user->user_login, $user);
				echo wp_send_json(array('status' => true, 'message' => ' <div class="alert alert-success">' . __('Login successful, reloading page...', 'ptheme') . '</div>'));
			}
		}

		die();
	}


	public function ast_hide_admin_bar()
	{
		if (current_user_can('subscriber') || current_user_can('author')) {
			// user can view admin bar
			show_admin_bar(false); // this line isn't essentially needed by default...
		}
	}

	public function isUserActivated($username)
	{

		// First need to get the user object
		$user = get_user_by('login', $username);
		if (!$user) {
			$user = get_user_by('email', $username);
			if (!$user) {
				return $username;
			}
		}

		$userStatus = get_user_meta($user->ID, 'is_activated', true);
		$userdata = get_userdata($user->ID);
		$user_roles = $userdata->roles;

		// Check if the role you're interested in, is present in the array.
		if (in_array('subscriber', $user_roles, true)) {

			if ($userStatus == 0) {
				echo wp_send_json(array('status' => false, 'message' => '<div class="alert alert-danger">Please verify your email address before login.</div>'));
			}
		}
	}
}
