<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://arsenaltech.com/
 * @since      1.0.0
 *
 * @package    Wp_login_signup
 * @subpackage Wp_login_signup/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wp_login_signup
 * @subpackage Wp_login_signup/public
 * @author     Rakesh <rakesh.bokde@arsenaltech.com>
 */


class Ast_Wp_signup
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Resister some shortcode function when wordpress install and activate.
	 *
	 * @since    1.0.0
	 */
	public function wp_ast_register_shortcode()
	{

		add_shortcode("ast-register", array($this, "generate_shortcode_for_ast_register"));

		add_action('show_user_profile', array($this, 'extra_user_profile_fields'));
		add_action('edit_user_profile', array($this, 'extra_user_profile_fields'));

		add_action('personal_options_update', array($this, 'save_extra_user_profile_fields'));
		add_action('edit_user_profile_update', array($this, 'save_extra_user_profile_fields'));
	}

	//Ast-Login Hmtl form 
	public function generate_shortcode_for_ast_register($attr)
	{

		ob_start();
		$args = shortcode_atts(array(
			'fclass' => 'default',
			'label' => 'true',
			'inputclass' => 'input-field',
			'buttonclass' => 'submit-button',
			'redirecturl' => get_home_url(),
			'logoutredirection' => get_home_url()

		), $attr);

		if (!is_user_logged_in()) { ?>
			<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post" class="<?php echo $args['fclass']; ?>" id="ast-register">

				<p class="status" id="status"></p>

				<p>
					<?php
					if ($args['label'] == 'false') {
					} else { ?>
						<label for="username"><?php esc_html_e('Username'); ?> <span class="error">*</span></label>
					<?php }
					?>
					<input type="text" name="username" placeholder="Enter Your Username" class="<?php echo $args['inputclass']; ?>" />
				</p>

				<p>
					<?php
					if ($args['label'] == 'false') {
					} else { ?>
						<label for="useremail"><?php esc_html_e('Email address'); ?> <span class="error">*</span></label>
					<?php }
					?>
					<input type="email" name="useremail" class="<?php echo $args['inputclass']; ?>" placeholder="Enter Your Email" />
				</p>

				<p>
					<?php
					if ($args['label'] == 'false') {
					} else { ?>
						<label for="password"><?php esc_html_e('Password'); ?> <span class="error">*</span></label>
					<?php }
					?>

					<input type="password" name="password" class="<?php echo $args['inputclass']; ?>" placeholder="Enter Your password" />
				</p>

				<input type="hidden" name="redirect_to" value="<?php echo $args['redirecturl']; ?>" class="<?php echo $args['inputclass']; ?>" id="redirect_to">
				<input type="submit" name="ast_user_registeration" value="<?php esc_html_e('Submit'); ?>" class="<?php echo $args['buttonclass'] ?>" />
				<?php wp_nonce_field('ajax-register-nonce', 'security'); ?>

			</form>
		<?php
		} else {  ?>
			<div class="sidebox">
				<?php global $current_user; ?>
				<h3>Welcome, <strong><?php echo $current_user->user_login; ?></strong></h3>
				<div class="usericon">
					<?php global $userdata;
					echo get_avatar($userdata->ID, 60); ?>

				</div>
				<div class="userinfo">
					<p>You’re logged in as <strong><?php echo $current_user->user_login; ?></strong></p>
					<p><?php $logouturl = $args['logoutredirection']; ?>
						<a href="<?php echo wp_logout_url($logouturl); ?>">Log out</a> |
						<?php if (current_user_can('manage_options')) {
							echo '<a href="' . admin_url() . '">' . __('Admin') . '</a>';
						} else {
							echo '<a href="' . admin_url() . 'profile.php">' . __('Profile') . '</a>';
						} ?>
					</p>
				</div>
			</div>
		<?php }

		$html_form = ob_get_clean();
		return $html_form;
	}


	public function handle_public_ajax_request_register()
	{

		$reg_errors = new WP_Error;
		$username = $_POST['username'];
		$useremail = $_POST['useremail'];
		$password = $_POST['password'];

		// Verify nonce
		if (!check_ajax_referer('ajax-register-nonce', 'security', false)) {
			echo wp_send_json(array('status' => false, 'message' => '<div class="alert alert-danger">Session token has expired, please reload the page and try again.</div>'));
		} elseif (get_option('users_can_register') == false) {

			echo wp_send_json(array('status' => false, 'message' => '<div class="alert alert-danger">New user can not be register on this site, Please check admin general setting.</div>'));
		} elseif (empty($username) || empty($useremail) || empty($password)) {
			echo wp_send_json(array('status' => false, 'message' => ' <div class="alert alert-danger">' . __('Required form field is missing', 'ptheme') . '</div>'));
		} elseif (6 > strlen($username)) {
			echo wp_send_json(array('status' => false, 'message' => ' <div class="alert alert-danger">' . __('Username too short. At least 6 characters is required', 'ptheme') . '</div>'));
		} elseif (username_exists($username)) {
			echo wp_send_json(array('status' => false, 'message' => ' <div class="alert alert-danger">' . __('The username you entered already exists!', 'ptheme') . '</div>'));
		} elseif (!validate_username($username)) {
			echo wp_send_json(array('status' => false, 'message' => ' <div class="alert alert-danger">' . __('The username you entered is not valid!', 'ptheme') . '</div>'));
		} elseif (!is_email($useremail)) {
			// $reg_errors->add( 'email_invalid', 'Email id is not valid!' );
			echo wp_send_json(array('status' => false, 'message' => ' <div class="alert alert-danger">' . __('Email id is not valid!', 'ptheme') . '</div>'));
		} elseif (email_exists($useremail)) {
			echo wp_send_json(array('status' => false, 'message' => ' <div class="alert alert-danger">' . __('Email Already exist!', 'ptheme') . '</div>'));
		} elseif (5 > strlen($password)) {
			echo wp_send_json(array('status' => false, 'message' => ' <div class="alert alert-danger">' . __('Password length must be greater than 5!', 'ptheme') . '</div>'));
		} else {

			global $username, $useremail;
			$username   =   sanitize_user($_POST['username']);
			$useremail  =   sanitize_email($_POST['useremail']);
			$password   =   esc_attr($_POST['password']);

			$userdata = array(
				'user_login'    =>   $username,
				'user_email'    =>   $useremail,
				'user_pass'     =>   $password,
			);
			$user = wp_insert_user($userdata);
			wp_update_user(array('ID' => $user, 'role' => 'subscriber'));
			// wp_new_user_notification($user);
			if ($user > 0) {

				// get user data
				$user_info = get_userdata($user);

				// create md5 code to verify later
				$code = md5(uniqid($user, true));

				// make it into a code to send it to user via email
				// $string = array('id'=>$user, 'code'=>$code);

				// create the activation code and activation status
				update_user_meta($user, 'account_activated', 0);
				update_user_meta($user, 'activation_code', $code);

				// create the url
				$url = get_site_url() . '/?act=' . base64_encode($code) . '&uid=' . base64_encode($user);

				$template = '<table><tr><td><H1>Welcome to "' . get_bloginfo('name') . '"</H1></td></tr><tr><td>your email verification link is <a href="' . $url . '">Click here to verify</a> </td></tr></table>';

				$headers[] = 'Content-type: text/html; charset=utf-8';
				$headers[] = 'From: ' . get_bloginfo("name") . ' <' . get_bloginfo("admin_email") . '>' . "\r\n";
				$message = $template;

				wp_mail($user_info->user_email, 'Registration on the site ' . get_bloginfo("name"), $message, $headers);

				echo wp_send_json(array('status' => true, 'message' => ' <div class="alert alert-success">' . __('Register successful, reloading page...', 'ptheme') . '</div>', 'id' => $message));
			} else {
				echo wp_send_json(array('status' => false, 'message' => '<div class="alert alert-danger">' . $user->get_error_message() . '</div>', 'id' => $user));
			}
		}
	}

	//verify user email id after registration
	public function verify_new_ast_user()
	{
		if (isset($_GET['act'])) {
			$userid = base64_decode($_GET['uid']);
			$urlact = base64_decode($_GET['act']);
			$databaseact =  get_user_meta($userid, 'activation_code', true);

			if ($databaseact == $urlact) {
				// update the user meta
				update_user_meta($userid, 'is_activated', 1);
				echo '<strong>Success:</strong> Your account has been activated! ';

				exit();
			}
		}
	}


	public function extra_user_profile_fields($user)
	{ ?>

		<h3><?php _e("Wp Login User activation", "blank"); ?></h3>
		<table class="form-table">
			<tr>
				<th><label for="is_activated"><?php _e("User activate"); ?></label></th>
				<td>
					<?php $data = get_user_meta($user->ID, 'is_activated', true); ?>
					<input name="is_activated" type="checkbox" id="is_activated" value="1" <?php
																							if (!empty($data) && !is_wp_error($data))
																								if ($data == true) {
																									echo 'checked';
																								}
																							?>>
				</td>
			</tr>
		</table>

<?php
	}

	public function save_extra_user_profile_fields($user_id)
	{
		if (empty($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'update-user_' . $user_id)) {
			return;
		}

		if (!current_user_can('edit_user', $user_id)) {
			return false;
		}
		update_user_meta($user_id, 'is_activated', $_POST['is_activated']);
	}
}
