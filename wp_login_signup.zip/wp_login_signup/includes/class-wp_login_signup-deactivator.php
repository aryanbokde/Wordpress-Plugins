<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://arsenaltech.com/
 * @since      1.0.0
 *
 * @package    Wp_login_signup
 * @subpackage Wp_login_signup/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wp_login_signup
 * @subpackage Wp_login_signup/includes
 * @author     Rakesh <rakesh.bokde@arsenaltech.com>
 */
class Wp_login_signup_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function deactivate() {

		$page_id = get_option('ast_login_signup');  

		if (!empty($page_id)) {
			foreach ($page_id as $key => $value) {    
				wp_delete_post($value, false);
			}
		}
	}

}
