<?php

/**
 * Fired during plugin activation
 *
 * @link       https://arsenaltech.com/
 * @since      1.0.0
 *
 * @package    Wp_login_signup
 * @subpackage Wp_login_signup/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wp_login_signup
 * @subpackage Wp_login_signup/includes
 * @author     Rakesh <rakesh.bokde@arsenaltech.com>
 */
class Wp_login_signup_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
    public function __construct()
    {
        //add_shortcode("rsb-archive", array($this, "generate_shortcode_for_ast_register"));
        
    }



	public  function activate() {

        global $wpdb;
        // Information needed for creating the plugin's pages

        //[ast-login fclass="loginform" label="false" inputclass="form-control" buttonclass="submit-btn" redirecturl="http://localhost/buzztail/asts-login/" logoutredirection="http://localhost/buzztail/asts/"]

        //[ast-register fclass="registerform" label="false" inputclass="form-control" buttonclass="submit-btn" redirecturl="http://localhost/buzztail/asts-register/" logoutredirection="http://localhost/buzztail/asts-register/"]

        $page_definitions = array(
            'asts-login' => array(
                "post_title" => "Ast Login",
                'post_name' => "asts-login",
                'post_status'  => "publish",   
                'post_author'  => 1,   
                'post_content'  => '[ast-login fclass="loginform" label="false" inputclass="form-control" buttonclass="submit-btn"]',          
                'post_type'  => "page"  
            ),
            'asts-register' => array(
                "post_title" => "Ast Register",
                'post_name' => "asts-register",
                'post_status'  => "publish",   
                'post_author'  => 1,   
                'post_content'  => '[ast-register fclass="registerform" label="false" inputclass="form-control" buttonclass="submit-btn"]',        
                'post_type'  => "page"  
            ),
        );
        
        $pageid = array();
        foreach ( $page_definitions as $slug => $page ) {


            //Check that the page doesn't exist already
            $query = new WP_Query( 'pagename=' . $slug );
            if (  !$query->have_posts() ) {
                //Add the page using the data from the array above
                $pageid[] = wp_insert_post(array(
                        'post_content'   => $page['post_content'],
                        'post_name'      => $slug,
                        'post_title'     => $page['post_title'],
                        'post_status'    => 'publish',
                        'post_type'      => 'page',
                        'ping_status'    => 'closed',
                        'comment_status' => 'closed',
                    ), true
                );
                
            }
        }

        update_option( 'ast_login_signup', $pageid );        
   }



}




