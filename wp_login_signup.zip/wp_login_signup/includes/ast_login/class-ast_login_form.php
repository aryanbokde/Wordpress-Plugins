<?php

/**
 * The file that defines the core plugin class
 *
 */
class Wp_login_signup_Login {


	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 */

	/**
	 * Resister some shortcode function when wordpress install and activate.
	 *
	 * @since    1.0.0
	 */
	public function wp_ast_register_some_shortcode(){

		/**
		 * Run Some important function when wordpress install like add shortcode.
		 */

		 //add_shortcode( "ast-register", array($this, "generate_shortcode_for_ast_register"));
		 add_shortcode( "ast-login", array($this, "contact_form_shortcode"));

	}

	// Register a new shortcode: [cf_contact_form]

	public function contact_form_shortcode() {
	    ob_start(); 	    
	    $this->ast_login_Shortcode();
	    return ob_get_clean();
	}

	public function ast_login_form_Html(){ 
		global $userName, $passWord;

		?>

		<form name="loginform" action="" method="post">
			
		<p class="login-username"> 
			<label for="user_login">Username</label>
			<input type="text" name="userName" id="user_login" class="input" value="<?php ( isset( $_POST['userName'] ) ? $userName : null ) ?>">
		</p>
		<p class="login-password">
			<label for="user_pass">Password</label>
			<input type="password" name="passWord" id="user_pass" class="input" value="<?php ( isset( $_POST['passWord'] ) ? $passWord : null ) ?>" >
		</p>
		
		<p class="login-remember">
			<label><input name="rememberMe" type="checkbox" id="rememberme" value=""> Remember Me</label>
		</p>
		<p class="login-submit">
			<input type="hidden" name="login_Submit" >
			<input type="submit" name="wp-submit" id="wp-submit" class="button-primary" value="Log In">
			<input type="hidden" name="redirect_to" value="">
		</p>
			
		</form>			
		
    	<?php 

	}

	public function ast_login_form_Validation($userName, $passWord){ 

		// Make the WP_Error object global    
	    global $form_error;
	     
	    // instantiate the class
	    $form_error = new WP_Error;

	    // If any field is left empty, add the error message to the error object
	    if ( empty( $userName ) || empty( $passWord ) ) {
	        $form_error->add( 'field', 'No field should be left empty' );
	    }

	    if ( is_wp_error( $form_error ) ) {
	        foreach ( $form_error->get_error_messages() as $error ) {
	            echo '<div>';
	            echo '<strong>ERROR</strong>:';
	            echo $error . '<br/>';
	            echo '</div>';
	        }
	    }

	}

	public function ast_login_form_Main( $userName, $passWord) {
	    global $form_error;
	    $creds=array();
	     
	    // Ensure WP_Error object ($form_error) contain no error
	    if ( 1 > count( $form_error->get_error_messages() ) ) {	                   			

			$creds['user_login']    = $userName;
			$creds['user_password'] = $passWord;
			$secure_cookie          = true;
	
			$userdata = wp_signon($creds, $secure_cookie);

			if ($userdata) {
				wp_clear_auth_cookie();
				wp_set_current_user($userdata->ID, $userdata->user_login);
			    wp_set_auth_cookie($userdata->ID, true);
				do_action('wp_login', $userdata->user_login);

				if ( is_user_logged_in() ){
                    $redirect_to=site_url();
                    wp_safe_redirect($redirect_to);
                    exit();
                }

			} 
	    }
	}

	public function ast_login_Shortcode() {
	    global $userName, $passWord;
	    if(isset($_POST['login_Submit'])) {
	        // Get the form data
	        $userName           =   $_POST['userName'];
	        $passWord          =   $_POST['passWord'];
	        $rememberMe   =   $_POST['rememberMe'];
	         
	        // validate the user form input
	        $this->ast_login_form_Validation($userName, $passWord);
	         
	        // send the mail
	        $this->ast_login_form_Main($userName, $passWord);
	 
	    }
	     
	    // display the Login Form
	    $this->ast_login_form_Html();
	}

	



}
