<?php
// Load the parent class if it doesn't exist.
if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Create Table
 */
if ( ! class_exists( 'Prefix_My_Table' ) ) :
    class Prefix_My_Table extends WP_List_Table {

        /**
         * Get a list of columns.
         *
         * @return array
         */
        public function get_columns() {
            return array(
                'cb' => '<input type="checkbox" name="bulk-delete[]" value="%s" />',
                'id'      => wp_strip_all_tags( __( 'ID' ) ),
                'title'   => wp_strip_all_tags( __( 'Title' ) ),
                'content'   => wp_strip_all_tags( __( 'Content' ) ),
                'status'   => wp_strip_all_tags( __( 'Status' ) ),
            );
        }

        /**
         * Prepares the list of items for displaying.
         */
        public function prepare_items() {
            $columns  = $this->get_columns();
            $hidden   = array();
            $sortable = array();
            $primary  = 'id';
            $this->_column_headers = array( $columns, $hidden, $sortable, $primary );

        }

        /**
         * Generates content for a single row of the table.
         * 
         * @param object $item The current item.
         * @param string $column_name The current column name.
         */
        protected function column_default( $item, $column_name ) {
            switch ( $column_name ) {
                case 'cd':
                    return esc_html( $item['cd'] );
                case 'id':
                    return esc_html( $item['id'] );
                case 'title':
                    return esc_html( $item['title'] );
                case 'content':
                    return esc_html( $item['content'] );
                case 'status':
                    return esc_html( $item['status'] );
                return 'No Post Found';
            }
        }


        public function column_cb( $item ) {
            return sprintf(
            '<input type="checkbox" name="bulk-delete[]" value="%s" />', $item['id']
            );
        }

        /**
         * Generates custom table navigation to prevent conflicting nonces.
         * 
         * @param string $which The location of the bulk actions: 'top' or 'bottom'.
         */
        protected function display_tablenav( $which ) {
            ?>
            <div class="tablenav <?php echo esc_attr( $which ); ?>">

                <div class="alignleft actions bulkactions">
                    <?php $this->bulk_actions( $which ); ?>
                </div>
                <?php
                $this->extra_tablenav( $which );
                $this->pagination( $which );
                
                ?>

                <br class="clear" />
            </div>
            <?php
        }

        /**
         * Generates content for a single row of the table.
         *
         * @param object $item The current item.
         */
        public function single_row( $item ) {
            echo '<tr>';
            $this->single_row_columns( $item );
            echo '</tr>';
        }
    }
endif;