<?php 

 /**
 * Create Database table for sms manager
 */  

function create_post_database(){
	    
	global $wpdb;
	$table_name = $wpdb->prefix . "ast_sms_manager";

    if ($wpdb->get_var("SHOW table like '".$table_name."'") != $table_name) {

        $sql =   "CREATE TABLE `".$table_name."` (

                            `ID` bigint(20) NOT NULL AUTO_INCREMENT,
                            `userId` int(11) NOT NULL,
                            `title` varchar(150) DEFAULT NULL,
                            `body` longtext DEFAULT NULL,
                            PRIMARY KEY (`ID`)

                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"; //table create query
        
        require_once(ABSPATH.'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
    }  
}


 /**
 * Delete Database table for sms manager
 */  

 function delete_post_database(){
	    
	global $wpdb;
	$table_name = $wpdb->prefix . "ast_sms_manager";

    $wpdb->query("DROP TABLE IF EXISTS ".$table_name);

}


function create_sms_database(){
        
    global $wpdb;
    $table_name = $wpdb->prefix . "sms_manager";

    if ($wpdb->get_var("SHOW table like '".$table_name."'") != $table_name) {

        $sql =   "CREATE TABLE `".$table_name."` (

                            `ID` mediumint(9) NOT NULL AUTO_INCREMENT,
                            `time` datetime DEFAULT '00-00-0000 00:00:00' NOT NULL,
                            `balance` tinytext NOT NULL,
                            PRIMARY KEY (`ID`)

                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"; //table create query
        
        require_once(ABSPATH.'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
    }  
}


function insert_initial_data(){
    global $wpdb;
    $table_name = $wpdb->prefix . "sms_manager";
    $wpdb->insert($table_name, array(
        'time' => current_time('mysql'),
        'balance' => '0'
    ));
}


 /**
 * 
 */  

 function update_the_database_balance(){
        
    global $wpdb;
    $table_name = $wpdb->prefix . "sms_manager";

    // Get the last entry in the database    
    $results = $wpdb->get_results("SELECT * FROM '.$table_name.' ORDER BY ID DESC LIMIT 1");
    //var_dump($results->balance);

    // entry is == get_option('ast_sms_account_balance')
    if ( $results->balance == get_option('ast_sms_account_balance') ) {
        return;
    }
    
    $wpdb->insert($table_name, array(
            'time' => current_time('mysql'),
            'balance' => get_option('ast_sms_account_balance')
        )
    );

}


 /**
 * Delete Database table for sms manager
 */  

 function delete_sms_database(){
        
    global $wpdb;
    $table_name = $wpdb->prefix . "sms_manager";

    $wpdb->query("DROP TABLE IF EXISTS ".$table_name);

}


function store_sms_database(){
        
    global $wpdb;
    $table_name = $wpdb->prefix . "store_sms_manager";

    if ($wpdb->get_var("SHOW table like '".$table_name."'") != $table_name) {

        $sql =   "CREATE TABLE `".$table_name."` (

                            `ID` int(11) NOT NULL AUTO_INCREMENT,
                            `LogID` varchar(255) NOT NULL,
                            `Type` varchar(255) NOT NULL,
                            `Country_code` mediumint(9) NOT NULL,
                            `Mobile` varchar(50) NOT NULL,
                            `Message` varchar(255) NOT NULL,
                            `From` varchar(50) NOT NULL,
                            `Status` int(11) NOT NULL DEFAULT 1,
                            `time` datetime DEFAULT '00-00-0000 00:00:00' NOT NULL,
                            PRIMARY KEY (`ID`)

                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"; //table create query
        
        require_once(ABSPATH.'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
    }  
}


 function delete_store_sms_database(){
        
    global $wpdb;
    $table_name = $wpdb->prefix . "store_sms_manager";

    $wpdb->query("DROP TABLE IF EXISTS ".$table_name);

}