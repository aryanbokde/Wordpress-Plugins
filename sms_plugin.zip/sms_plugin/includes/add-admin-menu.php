<?php 
/**
 * Register a custom menu page
 */

function ast_register_my_custom_menu_page(){
    
    add_menu_page( 'SMS Plugin Setting', 'Sms Plugin', 'manage_options', 'sms-plugin.php', 'get_account_post_data', 'dashicons-testimonial', 85 );    

    add_submenu_page('sms-plugin.php', 'Get Data', 'Get Data', 'manage_options', 'sms-plugin.php', 'get_account_post_data');

    add_submenu_page('sms-plugin.php', 'Post Data', 'Post Data', 'manage_options', 'post-data.php', 'get_sms_send_data');

    add_submenu_page('sms-plugin.php', 'Sms Balance', 'Sms Balance', 'manage_options', 'sms-balance.php', 'get_sms_balance');

    add_submenu_page('sms-plugin.php', 'Sms Send', 'Sms Send', 'manage_options', 'sms-send.php', 'post_sms_to_user');

    add_submenu_page('sms-plugin.php', 'Api Config', 'Api Config', 'manage_options', 'api-config.php', 'api_config_for_voice_sms');

    add_submenu_page('sms-plugin.php', 'Voice Call', 'Voice Call', 'manage_options', 'voice-call.php', 'post_voice_call_to_user');

    add_submenu_page('sms-plugin.php', 'Create Post Data', 'Create Post Data', 'manage_options', 'create-post-data', 'create_api_post_data');

    add_submenu_page('sms-plugin.php', 'Get Post Data', 'Get Post Data', 'manage_options', 'get-post-data', 'get_api_post_data');
}


/**
 * Get all sms balance detail from api and store in database 
 */
function get_account_post_data(){

    ob_start();
    include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/partials/sms_plugin-get-post.php' );
    $template = ob_get_contents();
    ob_clean();
    echo $template;

}


/**
 * Get all sms send record from api and display on page
 */

function get_sms_send_data(){

    ob_start();
    include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/partials/sms_plugin-get-send-data.php' );
    $template = ob_get_contents();
    ob_clean();
    echo $template;

}

add_action('admin_menu', 'ast_register_my_custom_menu_page');   


/**
 * Get all sms send record from api and display on page
 */

function get_sms_balance(){

    ob_start();
    include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/partials/sms-plugin-get-balance.php' );
    $template = ob_get_contents();
    ob_clean();
    echo $template;  

}

function post_sms_to_user(){

    ob_start();
    include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/partials/sms-plugin-post-sms-to-user.php' );
    $template = ob_get_contents();
    ob_clean();
    echo $template; 

}


function post_voice_call_to_user(){

    ob_start();
    include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/partials/sms-plugin-send-voice-call.php' );
    $template = ob_get_contents();
    ob_clean();
    echo $template; 
    
}


function api_config_for_voice_sms(){

    ob_start();
    include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/partials/api-config-setting.php' );
    $template = ob_get_contents();
    ob_clean();
    echo $template; 

}

function create_api_post_data()
{

    ob_start();
    include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/crud-api/create-api-post-data.php' );
    $template = ob_get_contents();
    ob_clean();
    echo $template; 

}

function get_api_post_data()
{
    
    $action = isset($_GET['action']) ? trim($_GET['action']) : "";

    if ($action == "owt-edit") {

        $post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : "";
        ob_start();
        include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/crud-api/edit-api-post-data.php' );
        $template = ob_get_contents();
        ob_clean();
        echo $template; 

    }elseif($action == "owt-delete"){

        $post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : "";
        ob_start();
        include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/crud-api/delete-api-post-data.php' );
        $template = ob_get_contents();
        ob_clean();
        echo $template;         

    }else{

        ob_start();
        include_once( SMS_PLUGIN_PLUGIN_PATH . 'admin/crud-api/get-api-post-data.php' );
        $template = ob_get_contents();
        ob_clean();
        echo $template; 

    }

}




function write_to_file( $message, $file_link){
    if ( file_exists( $file_link )) {
        $filling = fopen($file_link, "a");
        fwrite($filling, $message .'\n', 255);
        
    }else{
        $filling = fopen($file_link, "w");
        fwrite($filling, $message. '\n', 255);
        
    }fclose($filling);
    
    
}