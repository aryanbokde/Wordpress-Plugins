<?php 

/**
 * Add new user role in wordpress
 */
//add_action('init', 'sms_manager_add_user_role');

function sms_manager_add_user_role(){
    // remove_role('sms_manager');
    add_role(
        'sms_manager',
        'Sms Manager',
        array(
            'read'         => true,  // true allows this capability
            'publish_posts' => true,
            'edit_posts'   => true,
            'delete_posts' => false, // Use false to explicitly deny
        )
    );
}


/**
 * Remove user role in wordpress
 */
function sms_manager_deregister_role(){
    remove_role('sms_manager');
}