<?php 

/**
 * 
 */
class sms_plugin_common_function {

	function table_name() {
		global $wpdb;
		$table_name = $wpdb->prefix . "ast_sms_manager";
		return $table_name;
	}
	
}