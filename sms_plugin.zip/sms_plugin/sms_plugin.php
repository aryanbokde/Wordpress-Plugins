<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://arsenaltech.com/
 * @since             1.0.0
 * @package           Sms_plugin
 *
 * @wordpress-plugin
 * Plugin Name:       Sms plugin
 * Plugin URI:        https://arsenaltech.com/
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Rakesh
 * Author URI:        https://arsenaltech.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       sms_plugin
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */

define( 'SMS_PLUGIN_VERSION', '1.0.0' );
define( 'SMS_PLUGIN_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SMS_PLUGIN_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Include some required files.
 */
// require_once(SMS_PLUGIN_PLUGIN_PATH. 'includes/common-function.php');
require_once(SMS_PLUGIN_PLUGIN_PATH. 'includes/register-add-role.php');
require_once(SMS_PLUGIN_PLUGIN_PATH. 'includes/sms-database-manager.php');
require_once(SMS_PLUGIN_PLUGIN_PATH. 'includes/add-admin-menu.php');




/**
 * Run all the needed functions at the plugin activation.
 *
 * @function One : Create database for sms manager plugin
 * @function Two : Add new role for wordpress user for sms manager plugin
 * 
 */

function activation_initial_function(){
    create_post_database();
    sms_manager_add_user_role();
    create_sms_database();
    insert_initial_data();
    store_sms_database();
    
}

/**
 * Run all the needed functions at the plugin deactivation.
 *
 * @function One : Delete database for sms manager plugin
 * @function Two : Delete new role for wordpress user for sms manager plugin
 * 
 */

function deactivation_initial_function(){
    delete_post_database();
    sms_manager_deregister_role();
    delete_sms_database();
    delete_store_sms_database();
}

register_activation_hook( __FILE__, 'activation_initial_function' );
register_deactivation_hook( __FILE__,  'deactivation_initial_function');


