<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * When populating this file, consider the following flow
 * of control:
 *
 * - This method should be static
 * - Check if the $_REQUEST content actually is the plugin name
 * - Run an admin referrer check to make sure it goes through authentication
 * - Verify the output of $_GET makes sense
 * - Repeat with other user roles. Best directly by using the links/query string parameters.
 * - Repeat things for multisite. Once for a single site in the network, once sitewide.
 *
 * This file may be updated more in future version of the Boilerplate; however, this is the
 * general skeleton and outline for how the file should work.
 *
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @link       https://arsenaltech.com/
 * @since      1.0.0
 *
 * @package    Sms_plugin
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}



    if (is_wp_error( $response )) {

        $error_message = $response->get_error_message();
        echo "something went wrong: $error_message";

    }else{
        $body           = wp_remote_retrieve_body( $response );
        $response_code  = wp_remote_retrieve_response_code( $response );
        $last_modified  = wp_remote_retrieve_header( $response, 'last-modified' );
        $headerResult   = wp_remote_retrieve_headers($response);
        $message        = wp_remote_retrieve_response_message( $response );

        if ($response_code == 200 || $message == 'OK') {
            // echo 'its working code : ' .$response_code.'<br>';
            // echo 'its working message : ' .$message.'<br>';
            //echo $headerResult['x-content-type-options'];
            $body_data = json_decode($body);

            // echo "<pre>";
            // print_r($body);

            ?>

            <table class="widefat fixed" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>City</th>
                        <th>Zipcode</th>
                        <th>Phone</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($body_data as $key => $value) { ?>
                    <tr>
                        <td><?php echo $value->id; ?></td>
                        <td><?php echo $value->name; ?></td>
                        <td><?php echo $value->username; ?></td>
                        <td><?php echo $value->email; ?></td>
                        <td><?php echo $value->address->city; ?></td>
                        <td><?php echo $value->address->zipcode; ?></td>
                        <td><?php echo $value->phone; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>

            
            <?php 

        }

        

    }