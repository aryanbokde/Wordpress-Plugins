
<?php 

    // $load = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/wp-load.php';
    // // echo $load;
    // if (file_exists($load)) {
    //     require_once($load);
    // }

    if (isset($_POST['submit_post_data'])) {

        $success_msg = [];
        $error_message = [];
        $title = isset($_POST['title']) ? $_POST['title'] : '';
        $content = isset($_POST['content']) ? $_POST['content'] : '';
        $status = isset($_POST['status']) ? $_POST['status'] : '';
        //echo $status;

        if ( empty($title) || empty($content)) {
            $error_message['empty'] = " All fields is required";
        }

        $url = 'http://localhost/buzztail/wp-json/wp/v2/posts';    
        $arg = array(     
            "headers" => array(
                "Authorization" => "Basic " . base64_encode('asttech:asttech@123')
            ),
            "body"   => array(
                "title" => $title,
                "content" => $content,
                'status' => $status
            )
        );

        if (empty($error_message)) {

            $response = wp_remote_post($url,$arg);
            $body = wp_remote_retrieve_body( $response );
            $response_code = wp_remote_retrieve_response_code($response);
            
            if ($response_code == 200 || $response_code == 201) {
                echo "post created";
            }else{
                echo "post not created";
            }
        }
    
    }



  


?>




<h1>Post Data</h1>      
<div class="Postdata">
    <form method="post" id="postdata">
        <table style="border:none; width:100%;">
            <tbody>
                <?php 

                    if (isset($_POST['submit_post_data'])) { 
                        echo $error_message['empty'];
                    }

                ?>
                <tr style="width:100%;">
                    <td style="border:none; width:100%; "><label>Title</label><input type="text" name="title" style="width:100%;">
                </td>
                </tr>
                <tr style="width:100%;">
                    <td style="border:none; width:100%;"><label>Content</label>
                        <?php 
                            
                            $id = "content";
                            $name = 'content';
                            $content = esc_textarea( stripslashes( $data->content->rendered ) );
                            $settings = array('tinymce' => true, 'textarea_name' => "content");
                            wp_editor($content, $id, $settings);

                        ?>
                    </td>
                </tr>
                <tr style="width:100%;">
                    <td style="border:none; width:100%;"><label>Status</label>
                        <select name="status" style="width:100%;">
                            <option value="publish">Publish</option>
                            <option value="draft">Draft</option>
                        </select>
                   </td>
                </tr>
                <tr>
                     <td style="border:none;"><input type="submit" name="submit_post_data"></td>
                </tr>
            </tbody>
        </table>                  
    </form>
</div>