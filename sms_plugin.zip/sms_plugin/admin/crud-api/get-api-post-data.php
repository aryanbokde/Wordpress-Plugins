<?php 


// Load the parent class if it doesn't exist.
if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}


class OWTTableList extends WP_List_Table{



    public function wp_list_table_data($orderby = '', $order = '', $search_terms = ''){


        $url_old = 'http://localhost/buzztail/wp-json/wp/v2/posts'; 

        $arg = array(     
            "method" => "GET"
        );

        $response_old = wp_remote_post($url_old,$arg);
        
        $headerResult = wp_remote_retrieve_headers($response_old);
        $headerResultForPrint = (array)$headerResult;
        foreach($headerResultForPrint as $value){
            $total_posts = $value['x-wp-total'];
            $total_pages = $value['x-wp-totalpages'];
        }

        if (!empty($search_terms)) {
            
            $url = 'http://localhost/buzztail/wp-json/wp/v2/posts?per_page='.$total_posts.'&search="'.$search_terms.'"'; 

        }else{
            if ($orderby == "title" && $order =="asc") {

                $url = 'http://localhost/buzztail/wp-json/wp/v2/posts?per_page='.$total_posts.'&filter[orderby]=date&order=asc';        

            }elseif($orderby == "title" && $order =="desc"){

                $url = 'http://localhost/buzztail/wp-json/wp/v2/posts?per_page='.$total_posts.'&filter[orderby]=date&order=desc'; 
            }else{

                $url = 'http://localhost/buzztail/wp-json/wp/v2/posts?per_page='.$total_posts.'&filter[orderby]=date&order=desc'; 
            }
        }

        $arg = array(     
            "method" => "GET",
        );

        $response = wp_remote_post($url,$arg);
        $body = wp_remote_retrieve_body( $response );
        $response_code = wp_remote_retrieve_response_code($response);
        $datas = json_decode($body);
        
        $data = [];



        if (is_array($datas) || is_object($datas))
        {
            foreach ($datas as $value)
            {
                $postid = $value->id;
                $title = $value->title->rendered;
                $content_lenght = wp_trim_words( $value->content->rendered, 10);
                $content = wp_strip_all_tags($content_lenght, true);
                $status = $value->status;

                $data[] = array(
                    'id' => $postid,
                    'title' => $title,                    
                    'content' => $content,
                    'status' => $status,
                );
            }
        }

        return $data;


    }
    
   

    public function prepare_items(){

        $orderby = isset($_GET['orderby']) ? trim($_GET['orderby']) : "";
        $order = isset($_GET['order']) ? trim($_GET['order']) : "";
        
        $search_terms = isset($_POST['s']) ? trim($_POST['s']) : "";


        // $this->items = $this->wp_list_table_data($orderby, $order, $search_terms);

        $all_data = $this->wp_list_table_data($orderby, $order, $search_terms);
        
        $per_page = get_option( 'posts_per_page' );
        $current_page = $this->get_pagenum();
        $total_items = count($all_data);

        $this->set_pagination_args(
            array(
                'total_items' => $total_items,
                'per_page' => $per_page
            )
        );


        // $this->items = $all_data;
        $this->items = array_slice($all_data, (($current_page-1) * $per_page), $per_page);

        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();

        $this->_column_headers = array($columns, $hidden, $sortable);

    }


    public function get_columns(){
        
        $columns = array(
            "id" => "ID",
            "title" => "Title",
            "content" => "Content",
            "status" => "Status",
            "hidden" => "Hidden",
            "action" => "Action"
        );

        return $columns;

    }


    public function get_hidden_columns(){

        return array("hidden");
        // return array("");

    }


    public function get_sortable_columns(){

        return array(

            "title" => array('title', false)
            // "id" => array('id', false)

        );
        
    }


    public function column_default($item, $column_name){

        switch ($column_name){

            case 'id' :            
            case 'title' :            
            case 'content' :
            case 'status' :
            case 'hidden' :
            return $item[$column_name];
            case 'action' :
            return '<a href="?page='.$_GET['page'].'&action=owt-edit&post_id='.$item['id'].'">Edit</a> | <a href="?page='.$_GET['page'].'&action=owt-delete&post_id='.$item['id'].'">Delete</a>';
            default:
            return "No data found";

        }

    }


    public function column_title($item){
        
        // $action = array(
        //     "edit" => printf('<a href="?page=%s&action=%s&post_id=%s">Edit</a>', $_GET['page'], 'owt-edit', $item['id']),
        //     "delete" => printf('<a href="?page=%s&action=%s&post_id=%s">Delete</a>', $_GET['page'], 'owt-delete', $item['id']),
        // );

        // return printf('%1$s %2$s', $item['title'], $this->row_actions($action));

        $action = array(
            "edit" => "<a href='?page=".$_GET['page']."&action=owt-edit&post_id=".$item['id']."'>Edit</a>",
            "delete" => "<a href='?page=".$_GET['page']."&action=owt-delete&post_id=".$item['id']."'>Delete</a>"
        );
        
        return sprintf('%1$s %2$s', $item['title'], $this->row_actions($action));
    }


}



function owt_show_data_list_table(){

    $owt_table = new OWTTableList();
   
    $owt_table->prepare_items();
    echo "<h1>Table list</h1>";
    echo "<form method='post' name='frm_search_post' action='".$_SERVER['PHP_SELF']."?page=get-post-data'>";
    $owt_table->search_box("Search Post(s)", "search_post_id");
    echo "</form>";
    $owt_table->row_actions_title();
    $owt_table->display();

}

owt_show_data_list_table();


