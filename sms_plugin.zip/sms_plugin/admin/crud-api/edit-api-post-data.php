<?php 

if (isset($_POST['submit_update_data'])) { 

    $success_msg = [];
    $error_message = [];
    $post_id = isset($_POST['postid']) ? $_POST['postid'] : '';
    $title = isset($_POST['post_title']) ? $_POST['post_title'] : '';
    $content = isset($_POST['post_content']) ? $_POST['post_content'] : '';
    $status = isset($_POST['status']) ? $_POST['status'] : '';

    if ( empty($title) || empty($content)) {
        $error_message['empty'] = " All fields is required";
    }

    // $update_url = 'http://localhost/buzztail/wp-json/wp/v2/posts/'.$post_id.'/';
    // $arg = array(     

    //     "headers" => array(
    //         "Authorization" => "Basic " . base64_encode('asttech:asttech@123')
    //     ),
    //     "body"   => array(
    //         "title" => $title,
    //         "content" => $content,
    //         'status' => $status
    //     )
    // );

    // $response = wp_remote_post($update_url, $arg);


    $api_response = wp_remote_post( 'http://localhost/buzztail/wp-json/wp/v2/posts/'.$post_id.'/', array(

        'headers' => array(
            "Authorization" => "Basic " . base64_encode('asttech:asttech@123')
        ),
        'body' => array(
           "title" => $title,
            "content" => $content,
            "status" => $status
        )

    ) );

    $response_code = wp_remote_retrieve_response_code($api_response);    
    echo $response_code;
    // $body = json_decode( $api_response['body']);

    // if ($response_code == "200") {
        
    //     echo "<pre>";
    //     print_r($body);
    //     echo "</pre>";
    // }
}



if (!empty($post_id)) {

    $url= 'http://localhost/buzztail/wp-json/wp/v2/posts/'.$post_id; 

    $arg = array(     
        "method" => "GET"
    );

    $response = wp_remote_post($url,$arg);
    $body = wp_remote_retrieve_body( $response );
    $response_code = wp_remote_retrieve_response_code($response);
    $data = json_decode($body);

?>

<h1>Edit Post Data</h1>      
<div class="Postdata">
    <form method="post" id="updatedata">
        <table style="border:none; width:100%;">
            <tbody>
                <?php 

                    // if (isset($_POST['submit_post_data'])) { 
                    //     echo $error_message['empty'];
                    // }

                ?>
                <tr style="width:100%;">
                    <td style="border:none; width:100%; ">
                        <label for="id"><?php _e( 'ID' ); ?></label>
                        <input id="postid" type="number" name="postid" value="<?php _e( $data->id ); ?>"  readonly style="width:100%"/>
                    </td>
                </tr>

                <tr style="width:100%;">
                    <td style="border:none; width:100%;">
                        <label for="post-title"><?php _e( 'Title' ); ?></label>
                        <input id="post-title" type="text" name="post_title" value="<?php _e( $data->title->rendered ); ?>" style="width:100%"/>
                    </td>
                </tr>
                <tr style="width:100%;">
                    <td style="border:none; width:100%;">
                        <label for="post-content"><?php _e( 'Content' ); ?></label>
                        <?php 
                            
                            $id = "post_content";
                            $name = 'post_content';
                            $content = esc_textarea( stripslashes( $data->content->rendered ) );
                            $settings = array('tinymce' => true, 'textarea_name' => "post_content");
                            wp_editor($content, $id, $settings);

                        ?>
                    </td>
                </tr>
                <tr style="width:100%;">
                    <td style="border:none; width:100%;">
                        <label for="post-status"><?php _e( 'Status' ); ?></label>
                        <?php 

                            if ($data->status == "publish") {
                                echo '<select name="status" style="width:100%;"><option value="publish">Publish</option><option value="draft">Draft</option></select>';
                            }else{
                                echo '<select name="status" style="width:100%;"><option value="draft">Draft</option><option value="publish">Publish</option></select>';
                            }

                        ?>

                       
                    </td>
                </tr>
                
                <tr>
                     <td style="border:none;"><input type="submit" name="submit_update_data"></td>
                </tr>
            </tbody>
        </table>                  
    </form>
</div>





<?php  

} else{
    echo "no post foumd";
}









