<?php 

    if (!empty($post_id)) {

        $api_response = wp_remote_post( 'http://localhost/buzztail/wp-json/wp/v2/posts/'.$post_id, array(
            // ?force=true to skip trash
            'method' => 'DELETE',
            'headers' => array(
                "Authorization" => "Basic " . base64_encode('asttech:asttech@123')
            )) 
        );

        // $response = wp_remote_post($url,$arg);
        $body = wp_remote_retrieve_body( $api_response );
        $response_code = wp_remote_retrieve_response_code($api_response);
        $data = json_decode($body);

    }
    if ($response_code == 200) {
        echo "post $post_id has been DELETED successfully";
    }
?>









