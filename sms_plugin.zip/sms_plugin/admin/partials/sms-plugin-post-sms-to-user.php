<?php 

 echo "<h1>Sms Send</h1>";

    $args = json_encode( array(

        'method' => 'SendSms',
            'userdata' => array (
                'username' => 'aryan',
                'password' => 'aryanbokde',
            ),
            'msgdata' => array (
                'number' => '256782889702', //256705691069
                'message' => 'Welcome to Sukuma please send a msg',
                'senderid' => 'sukuma',
            ),
        )
    );


    $url = 'http://sms.sukumasms.com/api/v1/json/';

    $arguments = array('method' => 'POST', 'body' => $args );
    
    $response = wp_remote_post($url, $arguments);
  
    echo "<pre>";
    print_r($response);

    if (is_wp_error( $response )) {

        $error_message = $response->get_error_message();
        echo "something went wrong: $error_message";

    }else{

        echo 'Response:<pre>';
        print_r($response);
        echo '</pre>'; 

    }