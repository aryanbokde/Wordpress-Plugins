<?php 

    global $wpdb;
    $table_name = $wpdb->prefix . "ast_sms_manager";

    $url = 'https://jsonplaceholder.typicode.com/posts/';
    $args = array(
        'method' => 'GET'
        );

    $response = wp_remote_post($url, $args);
    $datasend = [];

    if ( 200 == wp_remote_retrieve_response_code( $response ) ) {
        
        $file_link = SMS_PLUGIN_PLUGIN_PATH . '/data.json';
        $message = wp_remote_retrieve_body( $response );

        write_to_file($message, $file_link); 
        
        $body_data = json_decode($message);  

        $result = $wpdb->get_results('SELECT ID from '.$table_name.' WHERE ID IS NOT NULL');

        if(count($result) == 0){
            foreach ($body_data as $key => $value) { 

                $array = [

                    'userId'  => $value->userId,
                    'title' => $value->title,
                    'body'  => $value->body

                ];
                $wpdb->insert($table_name, $array);
            }
            
        }
        else{
            $delete = $wpdb->query("TRUNCATE TABLE $table_name");
            foreach ($body_data as $key => $value) { 

                $array = [

                    'userId'  => $value->userId,
                    'title' => $value->title,
                    'body'  => $value->body

                ];
                $wpdb->insert($table_name, $array);
            }
        }       

    }


    if ( 200 !== wp_remote_retrieve_response_code( $response ) || is_wp_error( $response ) ) {

        $file_link = SMS_PLUGIN_PLUGIN_PATH . '/error_log.txt';
        $error_message = $response->get_error_message();
        $message = date('d m Y g:i:a'). '' .wp_remote_retrieve_response_code($response). '' .$error_message;  
        echo $message;  
        write_to_file($message, $file_link);

    }

?>

<h1>Sms Records</h1>      
<table class="widefat fixed" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>UserId</th>
            <th>Title</th>
            <th>Body</th>
        </tr>
    </thead>
    <tbody>
        <?php 

            $data = $wpdb->get_results ( "SELECT * FROM $table_name" );
            foreach ($data as $key => $value) { 

        ?>
        <tr>
            <td><?php echo $value->ID; ?></td>
            <td><?php echo $value->userId; ?></td>
            <td><?php echo $value->title; ?></td>
            <td><?php echo $value->body; ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>
