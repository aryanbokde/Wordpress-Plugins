<?php 

 echo "<h1>Send Voice Call Sms</h1>";

/**
 * Authkey api setting for sending sms 
**/
if (isset($_POST['submit_voice_sms'])) {

    $success_msg = [];
    $error_message = [];
    $authkeyUrl = get_option('authkey_url');
    $authkey = get_option('authkey_api');
    
    $ccode = isset($_POST['ccode']) ? $_POST['ccode'] : '';
    $mobile = isset($_POST['mobile']) ? $_POST['mobile'] : '';
    $message = isset($_POST['message']) ? $_POST['message'] : '';
    $sname = isset($_POST['sname']) ? $_POST['sname'] : '';

    if (empty($ccode)) {
        $error_message['ccode'] = "Please enter country code";
    }
    if (empty($mobile)) {
        $error_message['mobile'] = "Please enter mobile number";
    }
    if (empty($message)) {
        $error_message['message'] = "Please enter your voice message";
    }
    if (!empty($sname)) {
        $add_sender = ' From ' . $sname;
    }else{
        $add_sender = "";
    }
    if (empty($authkeyUrl)) {
        $error_message['authkeyUrl'] = "Please enter your api url";
    }
    if (empty($authkey)) {
        $error_message['authkey'] = "Please enter your api key";
    }

    $paramArray = Array(
        'authkey' => $authkey,
        'mobile' => $mobile,
        'country_code' => $ccode,
        'voice' => $message.''.$add_sender,
        'sender' => $sname
    );
    
    $parameters = http_build_query($paramArray);
    $url = $authkeyUrl . $parameters; 
    $response = wp_remote_post($url);

    if (is_wp_error( $response )) {

       $error_message['response_error'] = $response->get_error_message();
       
    }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode($body);       
    

    if (empty($error_message) && $data->Message == "Submitted Successfully") {

        global $wpdb;
        $tablename = $wpdb->prefix.'store_sms_manager';

        $data = array(
            'LogID' => $data->LogID, 
            'Type' => 'voice',
            'Country_code' => $ccode, 
            'Mobile' => $mobile,
            'Message' => $message, 
            'From' => $sname, 
            'Status' => 1,
            'time' => current_time('mysql') 
        );

        $wpdb->insert( $tablename, $data);
        $success_msg['success'] = 'Your vioce msg has been send to '.$mobile;

    }else{

        global $wpdb;
        $tablename = $wpdb->prefix.'store_sms_manager';

        $data = array(
            'LogID' => $data->LogID, 
            'Type' => 'voice',
            'Country_code' => $ccode, 
            'Mobile' => $mobile,
            'Message' => $message, 
            'From' => $sname, 
            'Status' => 0,
            'time' => current_time('mysql') 
        );

        $wpdb->insert( $tablename, $data);
        $success_msg['failed'] = 'Unable to send sms check your api key ';

    }

}



?>

<form method="POST">
    <table width="95%">
        <tr>
            <?php 
            if (isset($_POST['submit_voice_sms'])) {
                echo '<p style="color:green; font-size:18px; margin:0;">'.$success_msg['success'].'</p>';
            } 
            if (isset($_POST['submit_voice_sms'])) {
                echo '<p style="color:red; font-size:18px; margin:0;">'.$error_message['response_error'].'</p>';
            }
            if (isset($_POST['submit_voice_sms'])) {
                echo '<p style="color:red; font-size:18px; margin:0;">'.$success_msg['failed'].'</p>';
            }
            if (isset($_POST['submit_voice_sms'])) {
                echo $error_message['authkeyUrl'];
            }
            if (isset($_POST['submit_voice_sms'])) {
                echo $error_message['authkey'];
            } 

            ?>
            <td width="10%">Country code</td>
            <td width="90%">
                <input type="number" name="ccode" style="width:100%; border:none;" value="" placeholder="Please enter Country code">   
                <?php if (isset($_POST['submit_voice_sms'])) {
                    echo $error_message['ccode'];
                } ?>             
            </td>
        </tr>
        <tr>
            <td width="10%">Mobile Number</td>
            <td width="90%">
                <input type="number" name="mobile" style="width:100%; border:none;" value="" placeholder="Please enter mobile number">   
                <?php if (isset($_POST['submit_voice_sms'])) {
                    echo $error_message['mobile'];
                } ?>             
            </td>
        </tr>
        <tr>
            <td width="10%">Message</td>
            <td width="90%">
                <textarea name="message" placeholder="Enter Your voice Message" style="width:100%; border:none;"></textarea>
                <?php if (isset($_POST['submit_voice_sms'])) {
                    echo $error_message['message'];
                } ?> 
            </td>
        </tr>
        <tr>
            <td width="10%">Sender Name</td>
            <td width="90%">
                <input type="text" name="sname" style="width:100%; border:none;" placeholder="Enter sender name">
                
            </td>
        </tr>
        
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="submit_voice_sms" value="Submit"/></td>
        </tr>

    </table>
</form>


<h1>Voice Sms Records</h1>      
<table class="widefat fixed" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>LogID</th>
            <th>Type</th>
            <th>Country_code</th>
            <th>Mobile</th>
            <th>Message</th>
            <th>Status</th>
            <th>time</th>
        </tr>
    </thead>
    <tbody>
        <?php 
            global $wpdb;
            $tablename = $wpdb->prefix.'store_sms_manager';
            $data = $wpdb->get_results ( "SELECT * FROM $tablename" );
            foreach ($data as $key => $value) { 

        ?>
        <tr>
            <td><?php echo $value->ID; ?></td>
            <td><?php echo $value->LogID; ?></td>
            <td><?php echo $value->Type; ?></td>
            <td><?php echo $value->Country_code; ?></td>
            <td><?php echo $value->Mobile; ?></td>
            <td><?php echo $value->Message; ?></td>
            <td><?php 
                if ($value->Status == 1) {
                    echo "<button style='color:white; background-color:green; border:none; padding:10px; width:100px;'>Success</button>";
                }else{
                    echo "<button style='color:white; background-color:red;border:none; padding:10px; width:100px;'>Failed</button>";
                }?>
            </td>
            <td><?php echo $value->time; ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>























































 























