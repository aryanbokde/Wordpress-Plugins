<?php 

echo "<h1>Authkey Api Setting</h1>";

global $wpdb;


if (isset($_POST['add_authkey_api'])) {
    $error_message = [];
    $authkey_api = isset($_POST['confused_about_treatment']) ? $_POST['confused_about_treatment'] : '';
    $authkeyUrl = isset($_POST['authkeyUrl']) ? $_POST['authkeyUrl'] : '';

    if (empty($authkey_api)) {
    	$error_message['authkey_api'] = "Please enter authkey api key";
    }

    if (empty($authkeyUrl)) {
    	$error_message['authkeyUrl'] = "Please enter valid Url";
    }

    if(get_option('authkey_api') == ""){
    	delete_option('authkey_api');        
        add_option('authkey_api', $authkey_api);
    }
    else {
        update_option('authkey_api', $authkey_api);
    }

    if(get_option('authkey_url') == ""){
    	delete_option('authkey_url');        
        add_option('authkey_url', $authkeyUrl);
    }
    else {
        update_option('authkey_url', $authkeyUrl);
    }


}
?>
<form method="POST">
    <table width="95%">
    	<tr>
            <td width="10%">Authkey Url</td>
            <td width="90%">
                <input type="url" name="authkeyUrl" style="width:100%; border:none;" value="<?php echo get_option('authkey_url'); ?>" >
                <?php if (isset($_POST['add_authkey_api'])) {
                 	echo $error_message['authkeyUrl'];
                } ?>
            </td>
        </tr>
        <tr>
            <td width="10%">Authkey APIs Key</td>
            <td width="90%">
                <input type="text" name="confused_about_treatment" style="width:100%; border:none;" value="<?php echo get_option('authkey_api'); ?>" >
                <?php if (isset($_POST['add_authkey_api'])) {
                	echo $error_message['authkey_api'];
                } ?>
            </td>
        </tr>
        
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="add_authkey_api" value="Submit"/></td>
        </tr>

    </table>
</form>
<p><strong>Demo purpose</strong></p>
<p>Documentation Link <input type="url" name="documentation" value="https://authkey.io/sms-api-docs"></p>
<p>Api link <input type="url" name="Api" value="https://api.authkey.io/request?"></p>
<p>Api Key <input type="url" name="Key" value="6c258550cdf9875c"></p>


