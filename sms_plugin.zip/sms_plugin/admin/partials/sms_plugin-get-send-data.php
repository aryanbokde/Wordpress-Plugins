<?php 

echo "<h1>Send Post Data</h1>";

$args = array(
    'post_type' => 'post',
    'posts_per_page' => get_option( 'posts_per_page' )
);

$query = new WP_Query($args);

$datasend = [];

if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();
        $array = [
            'title' => get_the_title(),
            'body'  => get_the_content(),
            'userID'=> 1
        ];

        array_push($datasend, $array);
        
    }
}


$data_push_to_api = json_encode($datasend);

    $url = 'https://jsonplaceholder.typicode.com/posts/';
    
    $arguments = array(
        'method' => 'POST',
        'body' => $data_push_to_api
        );

    $response = wp_remote_post($url, $arguments);

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        echo "something went wrong : $error_message ";
    }else{
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);
        echo "<pre>";
        print_r($response);
        echo "</pre>";
    }








































