<?php 

    echo "<h1>Sms Admin</h1>";

    global $wpdb; 

    $args = array(
        'method' => 'Balance',
        'userdata' => array(
            'username' => 'aryan',
            'password' => 'aryanbokde',
        )
    );


    $sms_url = 'http://sms.sukumasms.com/api/v1/json/';
    $arguments = array('method' => 'POST', 'body' => json_encode($args) );


    $response = wp_remote_post($sms_url, $arguments);


    if (is_wp_error( $response )) {

        $error_message = $response->get_error_message();
        echo "something went wrong: $error_message";

    }else{

        $sms = json_decode(wp_remote_retrieve_body($response));   
        // print_r($sms);     
        echo '<span style="color:green;"> Status : ' .$sms->Status. '</span><br>';
        echo '<span style="color:green;"> Balance : ' .number_format($sms->Balance, 0). '</span><br>';

    }

    //update_the_database_balance();

    if ($sms->Balance == get_option('ast_sms_account_balance')) {
        return;
    }
    
    update_option('ast_sms_account_balance', $sms->Balance);
    update_the_database_balance();